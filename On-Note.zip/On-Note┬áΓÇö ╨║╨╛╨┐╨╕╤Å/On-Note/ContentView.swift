//
//  ContentView.swift
//  On-Note
//
//  Created by Павел Магдыч on 15.04.2023.
//

import SwiftUI

struct Note: Identifiable, Codable {
    var id = UUID()
    var title: String
    var content: String
    var profile: Int
}


struct ContentView: View {
    @State var notes = [Note]()
    @State var showAddNoteView = false
    @State var newNoteTitle = ""
    @State var newNoteContent = ""
    
    @State var isSortByDate = true
    
    @State var profileNumber = 1
    @State var previousProfileNumber = 2
    @State var anotherProfileNumber = 3
    
    @State var animate: Bool = false
    @State var isProfileSelection: Bool = false
    
    var body: some View {
        ZStack {
            Circle()
                .foregroundColor(DrawingConstants.circleColorPink)
                .padding(40)
                .blur(radius: animate ? 80 : 120)
                .offset(x: animate ? -50 : -130, y: animate ? -30 : -100 )
                .task {
                    withAnimation(.easeInOut(duration: 7).repeatForever()) {
                        animate.toggle()
                    }
                }
            
            Circle()
                .foregroundColor(DrawingConstants.circleColorGreen)
                .padding(40)
                .blur(radius: animate ? 80 : 120)
                .offset(x: animate ? 100: 130, y: animate ? 150 : 100)
            
            
            VStack {
                HStack {
                    Text("On-Note")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        
                        .foregroundColor(.white)
                    
                    Spacer()
                    
                    Button {
                        withAnimation(.spring()) {
                            isSortByDate.toggle()
                        }
                    } label: {
                        if isSortByDate {
                            Text("Sorted:\nCreation")
                                .font(.callout)
                                .foregroundColor(Color.white)
                                .opacity(0.7)
                        } else {
                            Text("Sorted:\nA-a")
                                .font(.callout)
                                .foregroundColor(Color.white)
                                .opacity(0.7)
                        }
                    }
                }.padding([.top, .leading, .trailing], 60)
                
                RoundedRectangle(cornerRadius: 13)
                    .frame(height: 3)
                    .foregroundColor(Color(red: 1, green: 1, blue: 1, opacity: 0.3))
                    .padding(.horizontal)
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 20) {
                        let profileNotes = notes.filter { $0.profile == profileNumber }
                        
                        if profileNotes.isEmpty {
                            Text("Create a new note!")
                                .font(.body)
                                .foregroundColor(.white)
                                .padding(.all)
                                .frame(width: 400)
                        }
                        ForEach(sortedNotes(profileNotes, byDate: isSortByDate)) { note in
                            VStack(alignment: .leading, spacing: 5) {
                                if note.profile == profileNumber {
                                    CardView(notes: $notes, note: $notes.first(where: { $0.id == note.id })!)
                                }
                            }
                        }
                        
                    }
                }
                .onAppear(perform: {
                    let decoder = JSONDecoder()
                    if let savedNotes = UserDefaults.standard.array(forKey: "notes") as? [Data] {
                        do {
                            notes = try savedNotes.map { try decoder.decode(Note.self, from: $0) }
                        } catch {
                            print("Error decoding notes: \(error.localizedDescription)")
                        }
                    }
                })
                .padding(.bottom, 30)
                
                HStack {
                    Button(action: {
                    }) {
                        ZStack {
                            Circle()
                                .fill(.ultraThinMaterial)
                                .opacity(0.5)
                            
                            Circle()
                                .stroke(Color.white, lineWidth: 1)
                                .background(Color.clear)
                                .opacity(0.5)
                            Image(systemName: "star")
                                .foregroundColor(.yellow)
                                .padding(20)
                        }
                    }.frame(width: 50)
                    
                    Spacer()
                    
                    ZStack {
                            Button {
                                withAnimation(.easeInOut(duration: 0.5)) {
                                    let tempVariable: Int = anotherProfileNumber
                                    anotherProfileNumber = previousProfileNumber
                                    previousProfileNumber = profileNumber
                                    profileNumber = tempVariable
                                    isProfileSelection.toggle()
                                }
                            } label: {
                                ZStack {
                                    Circle()
                                        .foregroundColor(.purple)
                                    Text(isProfileSelection ? withAnimation(.easeInOut(duration: 0.1)) {String(anotherProfileNumber)} : "")
                                        .font(.title3)
                                        .fontWeight(.black)
                                        .foregroundColor(.white)
                                }
                            }
                            .frame(width: 70)
                            .opacity(0.6)
                            .offset(y: isProfileSelection ? withAnimation(.easeInOut(duration: 1)) { -90 } : 0)
                            
                            
                            Button {
                                withAnimation(.easeInOut(duration: 0.5)) {
                                    let tempVariable: Int = previousProfileNumber
                                    previousProfileNumber = profileNumber
                                    profileNumber = tempVariable
                                    isProfileSelection.toggle()
                                }
                            } label: {
                                ZStack {
                                    Circle()
                                        .foregroundColor(.purple)
                                    Text(isProfileSelection ? withAnimation(.easeInOut(duration: 0.1)) {String(previousProfileNumber)} : "")
                                        .font(.title3)
                                        .fontWeight(.black)
                                        .foregroundColor(.white)
                                }
                            }
                                .frame(width: 50)
                                .opacity(0.5)
                                .offset(y: isProfileSelection ? withAnimation(.easeInOut(duration: 2)) { -160 } : 0)
                            
                        
                        Button {
                            withAnimation(.spring()) {
                                isProfileSelection.toggle()
                            }
                        } label: {
                            ZStack {
                                Circle()
                                    .foregroundColor(.purple)
                                Text(String(profileNumber))
                                    .font(.title3)
                                    .fontWeight(.black)
                                    .foregroundColor(.white)
                            }
                        }
                        .frame(width: 90)
                        .opacity(0.7)
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        showAddNoteView = true
                    }) {
                        ZStack {
                            Circle()
                                .fill(.ultraThinMaterial)
                                .opacity(0.5)
                            
                            Circle()
                                .stroke(Color.white, lineWidth: 1)
                                .background(Color.clear)
                                .opacity(0.5)
                            Image(systemName: "plus")
                                .font(.title)
                                .foregroundColor(.white)
                                .padding(20)
                        }
                    }.frame(width: 50)
                    
                }.padding(.horizontal, 30.0)
            }
        }
        .background(
            LinearGradient(colors: [DrawingConstants.backgroundDark, DrawingConstants.backgroundLight], startPoint: .bottom, endPoint: .top)
        )
        .sheet(isPresented: $showAddNoteView) {
            AddNoteView(notes: $notes, newNoteTitle: $newNoteTitle, newNoteContent: $newNoteContent, isPresented: $showAddNoteView, profileNumber: $profileNumber)
        }
    }
    
    func sortedNotes(_ notes: [Note], byDate: Bool) -> [Note] {
        if byDate {
            return notes.sorted(by: { $0.id.hashValue > $1.id.hashValue })
        } else {
            return notes.sorted(by: { $0.title < $1.title })
        }
    }
    
    private struct DrawingConstants {
        static let backgroundDark = Color(red: 0.05, green: 0, blue: 0.17)
        static let backgroundLight = Color(red: 0.11, green: 0, blue: 0.37)
        static let circleColorPink = Color(red: 0.59, green: 0.15, blue: 0.56)
        static let circleColorGreen = Color(red: 0.15, green: 0.58, blue: 0.41)
    }
}

struct AddNoteView: View {
    @Binding var notes: [Note]
    @Binding var newNoteTitle: String
    @Binding var newNoteContent: String
    @Binding var isPresented: Bool
    @Binding var profileNumber: Int
    
    var body: some View {
        VStack {
            HStack {
                Text("Add Note")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 60)
                    .padding(.bottom, 40)
                
                Spacer()
                
                Button(action: {
                    newNoteTitle = ""
                    newNoteContent = ""
                    isPresented = false
                }) {
                    ZStack {
                        Circle()
                            .stroke(lineWidth: 2)
                            .foregroundColor(.gray)
                        
                        Image(systemName: "xmark")
                            .foregroundColor(.gray)
                    }
                    .frame(width: 34, height: 34)
                }
                
                
            }.padding(.horizontal, 40.0)
            
            VStack(alignment: .leading) {
                Text("Title")
                    .font(.headline)
                    .fontWeight(.bold)
                TextField("Write the title of your note", text: $newNoteTitle)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.bottom, 20)
                
                Text("Content")
                    .font(.headline)
                    .fontWeight(.bold)
                TextField("What do you want to note?", text: $newNoteContent)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.bottom, 40)
            }
            .padding(.horizontal, 30)
            
            Button(action: {
                if !newNoteTitle.isEmpty && !newNoteContent.isEmpty {
                    notes.append(Note(title: newNoteTitle, content: newNoteContent, profile: profileNumber))
                    saveNote()
                    newNoteTitle = ""
                    newNoteContent = ""
                    isPresented = false
                }
            }) {
                Text("Add Note")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .background(Color.purple)
                    .cornerRadius(10)
            }
            .padding(.horizontal, 30)
            
            Spacer()
        }
    }
    
    func saveNote() {
        let note = Note(title: newNoteTitle, content: newNoteContent, profile: profileNumber)
        let encoder = JSONEncoder()
        do {
            let encodedNote = try encoder.encode(note)
            var notes = UserDefaults.standard.array(forKey: "notes") as? [Data] ?? []
            notes.append(encodedNote)
            UserDefaults.standard.set(notes, forKey: "notes")
        } catch {
            print("Error encoding note: \(error.localizedDescription)")
        }
    }
}

struct CardView: View {
    @State var isSelected: Bool = false
    @State var deleteText: String = "Delete"
    @State var shareText: String = "Share"
    
    @Binding var notes: [Note]
    @Binding var note: Note
    
    var body: some View {
        ZStack(alignment: .center) {
            RoundedRectangle(cornerRadius: 25)
                .fill(.ultraThinMaterial)
                .opacity(0.4)
                .mask(RoundedRectangle(cornerRadius: 25))
            
            RoundedRectangle(cornerRadius: 25)
                .stroke(Color.white, lineWidth: 1)
                .background(Color.clear)
                .opacity(0.3)
            
            VStack {
                Text(note.title)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding()
                Text(note.content)
                    .font(.body)
                    .foregroundColor(.white)
                    .padding(.bottom)
                
                if isSelected {
                    HStack {
                        Button(action: {
                            let activityVC = UIActivityViewController(activityItems: [note.title, note.content], applicationActivities: nil)
                            UIApplication.shared.windows.first?.rootViewController?.present(activityVC, animated: true, completion: nil)
                        }, label: {
                            Text(shareText)
                                .foregroundColor(.white)
                        })
                        
                        Spacer()
                        
                        Button {
                            withAnimation(.easeInOut(duration: 0.4)) {
                                isSelected.toggle()
                            }
                            withAnimation(.easeInOut(duration: 0.8)) {
                                if let index = notes.firstIndex(where: { $0.id == note.id }) {
                                    notes.remove(at: index)
                                    
                                    let encoder = JSONEncoder()
                                    if let encodedData = try? encoder.encode(notes) {
                                        UserDefaults.standard.set(encodedData, forKey: "notes")
                                    }
                                }
                            }
                        } label: {
                            Text(deleteText)
                                .foregroundColor(.white)
                        }
                    }
                    .padding()
                }
            }
                
        }
        .padding(!isSelected ? 20 : 10)
        .frame(width: !isSelected ? 300 : .infinity, height: .infinity)
        .shadow(radius: 4, x: 5, y: 5)
        .onTapGesture {
            withAnimation(.easeInOut(duration: 0.1)) {
                if isSelected {
                    deleteText = ""
                    shareText = ""
                } else {
                    deleteText = "Delete"
                    shareText = "Share"
                }
            }
            withAnimation(.easeInOut(duration: 0.3)) {
                isSelected.toggle()
            }
        }
        
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
